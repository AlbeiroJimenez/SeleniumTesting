import time

from behave import given, when, then
from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

USER_AGENT    = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36'

@given('launch Firefox Browser I')
def setBrowser(context):
    fireFoxOptions = webdriver.FirefoxOptions()
    fireFoxOptions.set_preference("general.useragent.override", USER_AGENT)
    service = FirefoxService(executable_path=GeckoDriverManager().install())
    context.driver = webdriver.Firefox(service=service, options = fireFoxOptions)
    
@when('open a SauceDemo Login Page I')
def openLoginPage(context):
    context.driver.get('https://www.saucedemo.com/')
    
@when('Enter username "{user}" and password "{password}"')
def setupCredentials(context, user, password):
    WebDriverWait(context.driver, 10).until(EC.visibility_of_any_elements_located((By.XPATH, '//input[@id="user-name"]')))[0].send_keys(user)
    WebDriverWait(context.driver, 10).until(EC.visibility_of_any_elements_located((By.XPATH, '//input[@id="password"]')))[0].send_keys(password)

@when('Click en Login Button.')
def clickLogin(context):
    WebDriverWait(context.driver, 10).until(EC.visibility_of_any_elements_located((By.XPATH, '//input[@id="login-button"]')))[0].click()

@then('User must successfully login to the dashboard page.')
def verifyLogin(context):
    try:
        WebDriverWait(context.driver, 10).until(EC.visibility_of_any_elements_located((By.XPATH, '//button[@id="add-to-cart-sauce-labs-backpack"]')))
        try:
            WebDriverWait(context.driver, 10).until(EC.visibility_of_any_elements_located((By.XPATH, '//img[contains(@src,"/static/media/sl-404.168b1cce.jpg")]')))
            return 'Problems with this user'
        except:
            return 'Sucessfull Login'
    except:
        errorText = WebDriverWait(context.driver, 10).until(EC.visibility_of_any_elements_located((By.XPATH, '//h3[@data-test="error"]')))[0]
        return errorText.get_attribute('textContent')
    
@then('close I')
def closeBrowser(context):
    time.sleep(15)
    context.driver.quit()
    
@then('verify error.')
def verifyLogin(context):
    number = -1
    errorText = WebDriverWait(context.driver, 10).until(EC.visibility_of_any_elements_located((By.XPATH, '//h3[@data-test="error"]')))[0]
    assert number != -1
import time

from behave import given, when, then
from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

USER_AGENT    = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36'

@given('launch Firefox Browser')
def setBrowser(context):
    fireFoxOptions = webdriver.FirefoxOptions()
    fireFoxOptions.set_preference("general.useragent.override", USER_AGENT)
    service = FirefoxService(executable_path=GeckoDriverManager().install())
    context.driver = webdriver.Firefox(service=service, options = fireFoxOptions)

@when('open a SauceDemo Login Page')
def openLoginPage(context):
    context.driver.get('https://www.saucedemo.com/')

@then('verify that is the saucedemo login page')
def verifyLoginPage(context):
    title = context.driver.title
    try:
        loginButton = WebDriverWait(context.driver, 10).until(EC.visibility_of_any_elements_located((By.XPATH, '//input[@id="login-button"]')))
        if title == 'Swag Labs':
            return True
        else:
            return False
    except:
        return False
    
@then('close')
def closeBrowser(context):
    time.sleep(5)
    context.driver.quit()

@given('launch Firefox Browser again')
def loadBrowser(context):
    fireFoxOptions = webdriver.FirefoxOptions()
    fireFoxOptions.set_preference("general.useragent.override", USER_AGENT)
    service = FirefoxService(executable_path=GeckoDriverManager().install())
    context.driver = webdriver.Firefox(service=service, options = fireFoxOptions)

@when('open a diferent saucedemo webpage')
def loadPage(context):
    context.driver.get('https://www.google.com/')

@then('verify that is the saucedemo login page again')
def verifyPage(context):
    title = context.driver.title
    try:
        if title == 'Swag Labs':
            loginButton = WebDriverWait(context.driver, 10).until(EC.visibility_of_any_elements_located((By.XPATH, '//input[@id="login-button"]')))
            return True
        else:
            return False
    except:
        return False

@then('close the browser')
def closeBrowser(context):
    time.sleep(5)
    context.driver.quit()